Technetium - controller-friendly launcher (Windows)
1. Install Node.js (https://nodejs.org), LTS version.
2. Double-click run.bat (first run downloads Electron, ~1 min).
Optional: "npm run dist" builds a portable Technetium.exe in /dist.
Controls: D-pad/left stick or mouse wheel to move, A/X or click to launch, LB/RB switch tab, LT/RT jump 5, B first, X add game, Y refresh.
Tip: Steam Input can interfere with DS4 - if the pad isn't detected, close Steam or disable Steam Input for desktop.

UPDATES (installed build only)
1. Pick somewhere to host files: any web folder, or a GitHub release. For GitHub use
   https://github.com/YOUR-NAME/YOUR-REPO/releases/latest/download/
2. Put that address in package.json (build > publish > url), replacing CHANGE-ME.
3. Run "npm run dist". In the dist folder you get "Technetium-Setup-x.x.x.exe", latest.yml and a .blockmap file.
4. Install the Setup exe once. (This replaces the old portable exe.)
5. For each new version: raise "version" in package.json, run "npm run dist", and upload the
   Setup exe, latest.yml and .blockmap to the same place, replacing the old latest.yml.
6. In Technetium open Settings > Check for updates. It downloads, then choose Restart to install.
Technetium also checks quietly each time it starts.

GAME UPDATES (Steam games, without opening Steam)
Settings > "Check game updates" looks for newer versions of your Steam games. Games with one get an
UPDATE badge. Choose the same tile again (now "Update N games") to install them, with a progress bar.
It uses SteamCMD, Valve's official command-line tool. Technetium downloads it for you the first time.
First time only: a console window opens asking for your Steam password and Steam Guard code.
Type them there, then type  quit  and press Enter, and run the update again.
Tip: close Steam while updating, and don't update the same game in both places at once.
After an update Steam may do a quick file check on that game the next time it starts. That is normal.

PLATFORMS
Windows: run.bat to try it, "npm run dist" for the installer.
macOS / Linux: run ./run.sh to try it (chmod +x run.sh first), "npm run dist:mac" (on a Mac) or "npm run dist:linux" (on Linux).
Easiest for all three: push this project to GitHub and push a tag like v1.2.0. The workflow in
.github/workflows/release.yml builds Windows, macOS and Linux and attaches them to the release.
Xbox app games are found automatically on Windows (default XboxGames folder).
Favorites: press F or R3 (right stick click) on a game.
