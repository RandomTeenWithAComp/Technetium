const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const fs = require('fs'), path = require('path');
const { spawn, execSync, execFile, execFileSync } = require('child_process');
const { pathToFileURL } = require('url');
const os = require('os');
const plat = process.platform, home = os.homedir();

app.setPath('userData', path.join(app.getPath('appData'), 'gamehub')); // keep saved games/history from earlier versions
const storeFile = path.join(app.getPath('userData'), 'gamehub.json');
const load = () => { try { return JSON.parse(fs.readFileSync(storeFile, 'utf8')); } catch { return { custom: [], played: {} }; } };
const save = d => fs.writeFileSync(storeFile, JSON.stringify(d));
let win;
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) app.quit();
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.show(); win.focus(); } });
const toastUi = t => { if (win && !win.isDestroyed()) win.webContents.send('toast', t); };

function steamPath() {
  if (plat === 'win32') {
    try {
      const o = execSync('reg query "HKCU\\Software\\Valve\\Steam" /v SteamPath', { encoding: 'utf8' });
      const x = o.match(/SteamPath\s+REG_SZ\s+(.+)/); if (x) return path.normalize(x[1].trim());
    } catch {}
    return ['C:\\Program Files (x86)\\Steam', 'C:\\Program Files\\Steam'].find(p => fs.existsSync(p));
  }
  const c = plat === 'darwin' ? [path.join(home, 'Library', 'Application Support', 'Steam')]
    : [path.join(home, '.local', 'share', 'Steam'), path.join(home, '.steam', 'steam'), path.join(home, '.steam', 'root'),
       path.join(home, '.var', 'app', 'com.valvesoftware.Steam', '.local', 'share', 'Steam')];
  return c.find(p => fs.existsSync(path.join(p, 'steamapps')));
}

const badName = (n, id) => !n || n.trim() === id || /^\d+$/.test(n.trim()) || /^(app[\s_]?id|steam app)[\s_:]*\d*$/i.test(n.trim());
const pretty = s => (s || '').replace(/[_\-.]+/g, ' ').replace(/([a-z])([A-Z])/g, '$1 $2').trim();

function findLocal(sp, id, names) {
  const base = path.join(sp, 'appcache', 'librarycache'), dirs = [base, path.join(base, id)];
  try {
    for (const d of fs.readdirSync(path.join(base, id), { withFileTypes: true }))
      if (d.isDirectory()) dirs.push(path.join(base, id, d.name));
  } catch {}
  for (const n of names) for (const d of dirs) {
    const p = path.join(d, d === base ? id + '_' + n : n);
    if (fs.existsSync(p)) return pathToFileURL(p).href;
  }
}

function findGrid(sp, id) {
  try {
    for (const u of fs.readdirSync(path.join(sp, 'userdata')))
      for (const ext of ['png', 'jpg', 'jpeg', 'webp']) {
        const p = path.join(sp, 'userdata', u, 'config', 'grid', id + 'p.' + ext);
        if (fs.existsSync(p)) return pathToFileURL(p).href;
      }
  } catch {}
}

function steamGames() {
  const sp = steamPath(); if (!sp) return [];
  const libs = new Map(), addLib = p => libs.set(path.normalize(p).toLowerCase(), path.normalize(p));
  addLib(sp);
  try {
    const t = fs.readFileSync(path.join(sp, 'steamapps', 'libraryfolders.vdf'), 'utf8');
    for (const m of t.matchAll(/"path"\s+"([^"]+)"/g)) addLib(m[1].replace(/\\\\/g, '\\'));
  } catch {}
  const out = [], seen = new Set();
  for (const lib of libs.values()) {
    const dir = path.join(lib, 'steamapps'); let files = [];
    try { files = fs.readdirSync(dir); } catch { continue; }
    for (const f of files) {
      if (!/^appmanifest_\d+\.acf$/.test(f)) continue;
      try {
        const t = fs.readFileSync(path.join(dir, f), 'utf8');
        const appid = (t.match(/"appid"\s+"(\d+)"/) || [])[1];
        const name = (t.match(/\n\t"name"\s+"([^"]*)"/) || t.match(/"name"\s+"([^"]*)"/) || [])[1];
        const installdir = (t.match(/"installdir"\s+"([^"]*)"/) || [])[1];
        if (!appid || seen.has(appid) || /Steamworks Common|Linux Runtime|Proton|Redistributable/i.test(name || '')) continue;
        seen.add(appid);
        out.push({ id: 'steam:' + appid, appid, name, installdir,
          buildid: (t.match(/"buildid"\s+"(\d+)"/) || [])[1],
          beta: !['', 'public'].includes((t.match(/"BetaKey"\s+"([^"]*)"/) || [, ''])[1]),
          dir: installdir && path.join(dir, 'common', installdir),
          portrait: findLocal(sp, appid, ['library_600x900.jpg']), grid: findGrid(sp, appid), wide: findLocal(sp, appid, ['header.jpg', 'library_header.jpg']) });
      } catch {}
    }
  }
  return out;
}

async function getJson(url) {
  const ctl = new AbortController(), t = setTimeout(() => ctl.abort(), 6000);
  try { return await (await fetch(url, { signal: ctl.signal })).json(); } catch { return null; } finally { clearTimeout(t); }
}
async function fetchMeta(id) {
  const input = encodeURIComponent(JSON.stringify({ ids: [{ appid: +id }], context: { language: 'english', country_code: 'US' }, data_request: { include_assets: true, include_basic_info: true } }));
  const [a, b] = await Promise.all([
    getJson('https://store.steampowered.com/api/appdetails?appids=' + id + '&l=english'),
    getJson('https://api.steampowered.com/IStoreBrowseService/GetItems/v1?input_json=' + input)]);
  if (!a && !b) return null; // offline: don't cache
  const d = a && a[id] && a[id].success && a[id].data;
  const it = b && b.response && b.response.store_items && b.response.store_items[0], as = it && it.assets;
  const url = f => (as && as.asset_url_format && f) ? 'https://shared.cloudflare.steamstatic.com/store_item_assets/' + as.asset_url_format.replace('${FILENAME}', f) : null;
  return { v: 2, name: (d && d.name) || (it && it.name), header: d && d.header_image, capsule: d && (d.capsule_imagev5 || d.capsule_image),
    portrait: url(as && as.library_capsule_2x), portrait1: url(as && as.library_capsule) };
}

function epicGames() {
  if (plat !== 'win32') return [];
  const dir = 'C:\\ProgramData\\Epic\\EpicGamesLauncher\\Data\\Manifests', out = [];
  try {
    for (const f of fs.readdirSync(dir).filter(f => f.endsWith('.item'))) {
      const j = JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8'));
      if (!j.LaunchExecutable || !j.DisplayName) continue;
      out.push({ id: 'epic:' + (j.CatalogItemId || f), name: j.DisplayName, source: 'epic',
        exe: path.join(j.InstallLocation, j.LaunchExecutable), cwd: j.InstallLocation });
    }
  } catch {}
  return out;
}

const unxml = s => s.replace(/&amp;/g, '&').replace(/&apos;/g, "'").replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
function xboxGames() {
  if (plat !== 'win32') return Promise.resolve([]);
  const ps = "$ErrorActionPreference='SilentlyContinue';Get-AppxPackage | Where-Object { $_.InstallLocation -like '*\\XboxGames\\*' } | ForEach-Object { $m = Get-AppxPackageManifest $_; [pscustomobject]@{ n = $_.Name; f = $_.PackageFamilyName; l = $_.InstallLocation; a = @($m.Package.Applications.Application)[0].Id } } | ConvertTo-Json -Compress";
  return new Promise(res => execFile('powershell.exe', ['-NoProfile', '-Command', ps], { timeout: 25000, windowsHide: true, maxBuffer: 8e6 }, (err, out) => {
    try {
      let j = JSON.parse(out); if (!Array.isArray(j)) j = [j];
      res(j.filter(x => x && x.f && x.a).map(x => {
        let name = '', art;
        try {
          const t = fs.readFileSync(path.join(x.l, 'MicrosoftGame.config'), 'utf8');
          name = unxml((t.match(/DefaultDisplayName="([^"]+)"/) || [])[1] || '');
          const logo = (t.match(/Square480x480Logo="([^"]+)"/) || t.match(/Square150x150Logo="([^"]+)"/) || [])[1];
          if (logo && fs.existsSync(path.join(x.l, logo))) art = pathToFileURL(path.join(x.l, logo)).href;
        } catch {}
        if (!name || /^ms-resource/i.test(name)) name = path.basename(path.dirname(x.l)) || x.n;
        return { id: 'xbox:' + x.n, name, source: 'xbox', aumid: x.f + '!' + x.a, arts: art ? [art] : [] };
      }));
    } catch { res([]); }
  }));
}
let xbCache = null, xbAt = 0;
async function xboxCached() { if (xbCache && Date.now() - xbAt < 120000) return xbCache; xbCache = await xboxGames(); xbAt = Date.now(); return xbCache; }

const iconCache = {};
async function iconFor(exe) {
  if (iconCache[exe] !== undefined) return iconCache[exe];
  try { return (iconCache[exe] = (await app.getFileIcon(exe, { size: 'large' })).toDataURL()); } catch { return (iconCache[exe] = null); }
}

ipcMain.handle('list', async () => {
  const d = load(); d.meta = d.meta || {};
  const steam = steamGames();
  const xp = xboxCached();
  const need = steam.filter(g => ((!g.portrait && !g.grid) || badName(g.name, g.appid)) && (!d.meta[g.appid] || d.meta[g.appid].v !== 2));
  for (let i = 0; i < need.length; i += 8) {
    let ok = 0;
    await Promise.all(need.slice(i, i + 8).map(async g => { const r = await fetchMeta(g.appid); if (r) { d.meta[g.appid] = r; ok++; } }));
    if (!ok) break; // offline, stop waiting
  }
  if (need.length) save(d);
  const games = steam.map(g => {
    const m = d.meta[g.appid] || {}, cdn = 'https://cdn.cloudflare.steamstatic.com/steam/apps/' + g.appid + '/';
    return { id: g.id, source: 'steam', appid: g.appid,
      name: badName(g.name, g.appid) ? (m.name || pretty(g.installdir) || 'Steam app ' + g.appid) : g.name,
      arts: [g.portrait, g.grid, m.portrait, m.portrait1, cdn + 'library_600x900_2x.jpg', cdn + 'library_600x900.jpg',
        'https://shared.cloudflare.steamstatic.com/store_item_assets/steam/apps/' + g.appid + '/library_600x900.jpg',
        g.wide, m.header, m.capsule, cdn + 'header.jpg'].filter(Boolean) };
  });
  const names = new Set(games.map(g => g.name.toLowerCase())), ids = new Set(), exes = new Set(), out = [...games];
  for (const o of [...epicGames(), ...(await xp), ...d.custom.map(c => ({ ...c, source: 'custom' }))]) {
    const ek = (o.exe || '').toLowerCase();
    if (ids.has(o.id) || (ek && exes.has(ek)) || (o.source !== 'custom' && names.has(o.name.toLowerCase()))) continue;
    ids.add(o.id); if (ek) exes.add(ek); if (o.exe) o.icon = await iconFor(o.exe); out.push(o);
  }
  return out.map(g => ({ ...g, last: d.played[g.id] || 0 })).sort((a, b) => a.name.localeCompare(b.name));
});

// Hand the screen to the game, and tell the page to stop listening to the controller meanwhile.
let wasFull = false;
const toGame = on => { if (win && !win.isDestroyed()) win.webContents.send('gaming', on); };
function hideForGame() {
  toGame(true); wasFull = win.isFullScreen();
  if (wasFull) win.setFullScreen(false); // a fullscreen window won't always minimize, so leave fullscreen first
  setTimeout(() => { if (win && !win.isDestroyed()) win.minimize(); }, wasFull ? 300 : 0);
}
function backFromGame() {
  if (!win || win.isDestroyed()) return;
  win.restore(); if (wasFull) { wasFull = false; win.setFullScreen(true); }
  win.focus(); toGame(false);
}

ipcMain.handle('launch', (_, g) => {
  const d = load(); d.played[g.id] = Date.now(); save(d);
  let p;
  if (g.source === 'steam') shell.openExternal('steam://rungameid/' + g.appid);
  else if (g.source === 'xbox') spawn('explorer.exe', ['shell:AppsFolder\\' + g.aumid], { detached: true, stdio: 'ignore' }).unref();
  else {
    if (plat === 'darwin' && /\.app$/i.test(g.exe)) p = spawn('open', ['-W', '-a', g.exe], { detached: true, stdio: 'ignore' });
    else p = spawn(g.exe, [], { cwd: g.cwd || path.dirname(g.exe), detached: true, stdio: 'ignore' });
    p.on('error', () => { backFromGame(); toastUi('Could not start ' + g.name); });
    p.on('exit', backFromGame);
  }
  hideForGame();
});

ipcMain.handle('add', async () => {
  const filters = plat === 'win32' ? [{ name: 'Programs', extensions: ['exe', 'bat'] }] : plat === 'darwin' ? [{ name: 'Apps', extensions: ['app'] }] : [];
  const r = await dialog.showOpenDialog(win, { title: 'Choose a game', filters, properties: ['openFile'] });
  if (r.canceled) return false;
  const exe = r.filePaths[0], d = load();
  d.custom.push({ id: 'custom:' + Date.now(), name: path.basename(exe).replace(/\.\w+$/, ''), exe, cwd: path.dirname(exe) });
  save(d); return true;
});

ipcMain.handle('remove', (_, id) => { const d = load(); d.custom = d.custom.filter(c => c.id !== id); save(d); });
ipcMain.handle('fullscreen', () => win.setFullScreen(!win.isFullScreen()));
ipcMain.handle('quit', () => app.quit());

// ----- in-app updates (electron-updater; works in the installed build only) -----
function updateUrl() {
  try { const u = require('./package.json').build.publish[0].url; return /CHANGE-ME/i.test(u) ? '' : u; } catch { return ''; }
}
let updater;
const sendUp = s => { if (win && !win.isDestroyed()) win.webContents.send('update', s); };
function getUpdater() {
  if (updater !== undefined) return updater;
  try { updater = require('electron-updater').autoUpdater; } catch { return (updater = null); }
  updater.autoDownload = true; updater.autoInstallOnAppQuit = true;
  updater.on('checking-for-update', () => sendUp({ state: 'checking' }));
  updater.on('update-available', i => sendUp({ state: 'downloading', version: i.version, pct: 0 }));
  updater.on('update-not-available', () => sendUp({ state: 'uptodate' }));
  updater.on('download-progress', p => sendUp({ state: 'downloading', pct: Math.round(p.percent) }));
  updater.on('update-downloaded', i => sendUp({ state: 'ready', version: i.version }));
  updater.on('error', e => sendUp({ state: 'error', msg: String((e && e.message) || e).slice(0, 100) }));
  return updater;
}
async function fetchText(u) { try { const r = await fetch(u); return r.ok ? await r.text() : null; } catch { return null; } }
const isNewer = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); } return false; };
ipcMain.handle('update:check', async (_, manual) => {
  if (!app.isPackaged) return { state: 'dev' };
  let url = updateUrl(); if (!url) return { state: 'none' };
  if (!url.endsWith('/')) url += '/';
  if (plat === 'darwin') { // unsigned Mac apps can't replace themselves, so just point to the download
    const t = await fetchText(url + 'latest-mac.yml'), v = t && (t.match(/^version:\s*(\S+)/m) || [])[1];
    if (!v) return { state: 'error', msg: 'Could not check for updates' };
    if (!isNewer(v, app.getVersion())) return { state: 'uptodate' };
    if (manual) shell.openExternal(url.replace(/\/download\/$/, '/'));
    return { state: 'macnew', version: v };
  }
  if (plat === 'linux' && !process.env.APPIMAGE) return { state: 'unsupported' };
  const u = getUpdater(); if (!u) return { state: 'missing' };
  u.setFeedURL({ provider: 'generic', url });
  u.checkForUpdates().catch(() => {});
  return { state: 'checking' };
});
ipcMain.handle('update:install', () => { if (updater) updater.quitAndInstall(); });
ipcMain.handle('app:version', () => app.getVersion());

// ----- game updates via SteamCMD (Valve's official command-line client, using your own Steam login) -----
const scDir = () => path.join(app.getPath('userData'), 'steamcmd');
const scExe = () => path.join(scDir(), plat === 'win32' ? 'steamcmd.exe' : 'steamcmd.sh');
const sendGu = s => { if (win && !win.isDestroyed()) win.webContents.send('gu', s); };
let guBusy = false, guLatest = {};

function runSc(args, onLine, timeout) {
  return new Promise(res => {
    const p = spawn(scExe(), args, { cwd: scDir(), windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
    let out = '', buf = '';
    const t = timeout ? setTimeout(() => p.kill(), timeout) : null;
    const feed = c => { const s = c.toString(); out += s; if (onLine) { buf += s; const parts = buf.split(/[\r\n]+/); buf = parts.pop(); parts.forEach(onLine); } };
    p.stdout.on('data', feed); p.stderr.on('data', feed);
    p.on('error', () => { clearTimeout(t); res({ code: -1, out }); });
    p.on('close', code => { clearTimeout(t); if (onLine && buf) onLine(buf); res({ code, out }); });
  });
}

async function ensureSc() {
  if (fs.existsSync(scExe())) return true;
  try {
    sendGu({ state: 'msg', msg: 'Downloading SteamCMD…' });
    fs.mkdirSync(scDir(), { recursive: true });
    const file = { win32: 'steamcmd.zip', darwin: 'steamcmd_osx.tar.gz', linux: 'steamcmd_linux.tar.gz' }[plat];
    const r = await fetch('https://steamcdn-a.akamaihd.net/client/installer/' + file);
    const arc = path.join(scDir(), file);
    fs.writeFileSync(arc, Buffer.from(await r.arrayBuffer()));
    if (plat === 'win32') execSync(`powershell -NoProfile -Command "Expand-Archive -Force -LiteralPath '${arc}' -DestinationPath '${scDir()}'"`);
    else execFileSync('tar', ['-xzf', arc, '-C', scDir()]);
    fs.unlinkSync(arc);
    sendGu({ state: 'msg', msg: 'Setting up SteamCMD (first run, a minute or two)…' });
    await runSc(['+quit'], null, 300000);
    return fs.existsSync(scExe());
  } catch { return false; }
}

function openTerminal(args) {
  const cmd = `"${scExe()}" ${args}`;
  if (plat === 'win32') spawn(`start "SteamCMD sign-in" ${cmd}`, { shell: true, detached: true, stdio: 'ignore', cwd: scDir() }).unref();
  else if (plat === 'darwin') spawn('osascript', ['-e', `tell application "Terminal" to do script "${cmd.replace(/"/g, '\\"')}"`, '-e', 'tell application "Terminal" to activate'], { detached: true, stdio: 'ignore' }).unref();
  else for (const t of [['x-terminal-emulator', '-e'], ['gnome-terminal', '--'], ['konsole', '-e'], ['xfce4-terminal', '-e'], ['xterm', '-e']]) {
    try {
      execSync('command -v ' + t[0], { stdio: 'ignore' });
      spawn(t[0], [t[1], 'bash', '-c', cmd + '; echo; read -p "Press Enter to close"'], { detached: true, stdio: 'ignore', cwd: scDir() }).unref(); return;
    } catch {}
  }
}

function steamUser() {
  const sp = steamPath(); if (!sp) return null;
  try {
    const t = fs.readFileSync(path.join(sp, 'config', 'loginusers.vdf'), 'utf8');
    const blocks = [...t.matchAll(/"\d{17}"\s*\{([^}]*)\}/g)].map(x => x[1]);
    const b = blocks.find(x => /"MostRecent"\s+"1"/.test(x)) || blocks[0];
    return b && (b.match(/"AccountName"\s+"([^"]+)"/) || [])[1];
  } catch { return null; }
}

ipcMain.handle('gu:check', async () => {
  if (guBusy) return { error: 'Already working on it' };
  guBusy = true;
  try {
    if (!(await ensureSc())) return { error: 'Could not set up SteamCMD. Are you online?' };
    const d = load(), games = steamGames().filter(g => g.buildid && !g.beta), latest = {};
    for (let i = 0; i < games.length; i += 25) {
      sendGu({ state: 'msg', msg: 'Checking for updates… ' + Math.min(i + 25, games.length) + ' of ' + games.length });
      const ids = games.slice(i, i + 25).map(g => g.appid);
      const r = await runSc(['+login', 'anonymous', '+app_info_update', '1', ...ids.flatMap(x => ['+app_info_print', x]), '+quit'], null, 180000);
      const marks = [...r.out.matchAll(/^"(\d+)"\s*$/gm)];
      marks.forEach((mk, k) => {
        const chunk = r.out.slice(mk.index, k + 1 < marks.length ? marks[k + 1].index : undefined);
        const b = (chunk.match(/"branches"[\s\S]*?"public"\s*\{[\s\S]*?"buildid"\s+"(\d+)"/) || [])[1];
        if (b) latest[mk[1]] = b;
      });
    }
    guLatest = latest;
    const done = d.updated || {};
    return { updates: games.filter(g => latest[g.appid] && latest[g.appid] !== g.buildid && done[g.appid] !== latest[g.appid]).map(g => g.appid), checked: games.length };
  } finally { guBusy = false; }
});

ipcMain.handle('gu:run', async (_, list) => {
  if (guBusy) return { error: 'Already working on it' };
  guBusy = true;
  try {
    if (!(await ensureSc())) return { error: 'Could not set up SteamCMD. Are you online?' };
    const user = steamUser();
    if (!user) return { error: 'Could not find your Steam account. Sign in to Steam once first.' };
    sendGu({ state: 'msg', msg: 'Signing in to SteamCMD…' });
    const t = await runSc(['+login', user, '+quit'], null, 40000);
    if (!/Waiting for user info\.\.\.OK/.test(t.out)) {
      openTerminal('+login ' + user);
      return { signin: true };
    }
    const all = steamGames(); let ok = 0; const fail = [];
    for (let i = 0; i < list.length; i++) {
      const it = list[i], g = all.find(x => x.appid === it.appid);
      if (!g || !g.dir) { fail.push(it.name); continue; }
      let success = false, err = '';
      const tell = pct => sendGu({ state: 'update', name: it.name, pct, index: i + 1, total: list.length });
      tell(0);
      await runSc(['+force_install_dir', g.dir, '+login', user, '+app_update', it.appid, '+quit'], line => {
        const p = line.match(/progress:\s*([\d.]+)/); if (p) tell(Math.round(parseFloat(p[1])));
        if (/Success! App/.test(line)) success = true;
        const e = line.match(/ERROR! (.*)/); if (e) err = e[1];
      }, 0);
      if (success) { ok++; const dd = load(); (dd.updated = dd.updated || {})[it.appid] = guLatest[it.appid] || '1'; save(dd); }
      else fail.push(it.name + (err ? ' (' + err.slice(0, 50) + ')' : ''));
    }
    return { ok, fail };
  } finally { guBusy = false; }
});

// Start with Windows. A portable exe unpacks to a temp folder, so register the real exe path instead.
const loginOpts = () => ({ path: process.env.PORTABLE_EXECUTABLE_FILE || process.execPath, args: app.isPackaged ? [] : [app.getAppPath()] });
const autoFile = path.join(home, '.config', 'autostart', 'technetium.desktop');
const autoOn = () => plat === 'linux' ? fs.existsSync(autoFile) : app.getLoginItemSettings(loginOpts()).openAtLogin;
ipcMain.handle('auto:get', () => autoOn());
ipcMain.handle('auto:set', (_, on) => {
  if (plat === 'linux') {
    if (on) {
      fs.mkdirSync(path.dirname(autoFile), { recursive: true });
      fs.writeFileSync(autoFile, `[Desktop Entry]\nType=Application\nName=Technetium\nExec="${process.env.APPIMAGE || process.execPath}"\nX-GNOME-Autostart-enabled=true\n`);
    } else try { fs.unlinkSync(autoFile); } catch {}
  } else app.setLoginItemSettings({ openAtLogin: !!on, ...loginOpts() });
  return autoOn();
});

app.whenReady().then(() => {
  if (!gotLock) return;
  win = new BrowserWindow({
    width: 1280, height: 720, minWidth: 640, minHeight: 360,
    fullscreen: true, backgroundColor: '#000', icon: path.join(__dirname, plat === 'win32' ? 'icon.ico' : 'icon.png'), autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), autoplayPolicy: 'no-user-gesture-required', backgroundThrottling: false },
  });
  if (plat !== 'darwin') win.removeMenu(); // keep the standard menu on macOS so Cmd+Q works
  // The UI is designed for 1920x1080; zoom the page so it fits any window size.
  const fit = () => {
    const [w, h] = win.getContentSize();
    win.webContents.setZoomFactor(Math.max(0.45, Math.min(3, Math.min(w / 1920, h / 1080))));
  };
  ['resize', 'enter-full-screen', 'leave-full-screen', 'maximize', 'unmaximize', 'restore'].forEach(e => win.on(e, fit));
  win.webContents.on('did-finish-load', fit);
  win.on('restore', () => { if (wasFull) { wasFull = false; win.setFullScreen(true); } });
  win.on('focus', () => toGame(false));
  win.loadFile('index.html');
});
app.on('window-all-closed', () => app.quit());
